<?php 
	echo "Thanks for joining, " . $_POST["name"] . "!<br />";
	echo "A confirmation email might have been sent to: " . $_POST["email"] . " if this were a real site.";
?>